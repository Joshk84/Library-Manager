﻿namespace LibraryManager.Utilities
{
	public static class PanelUtilities
	{
		public const int PanelContentWidth = 911;
		public const int PanelContentHeight = 571;
	}
}