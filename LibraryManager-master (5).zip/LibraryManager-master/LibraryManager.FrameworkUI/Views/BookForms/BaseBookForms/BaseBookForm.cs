﻿using System.Windows.Forms;

namespace LibraryManager.FrameworkUI.Views.BookForms.BaseBookForms
{
	public partial class BaseBookForm : Form
	{
		protected BaseBookForm()
		{
			InitializeComponent();
		}
		
	}
}