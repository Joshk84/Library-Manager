﻿using System.Collections.Generic;
using LibraryManager.FrameworkUI.Views.BookForms.AddBookForms;

namespace LibraryManager.FrameworkUI.Extensions
{
	public static class BookFormExtensions
	{
		public static void AddSubjectListBox(this AddBookForm addBookForm, List<string> list)
		{
			
		}
		
		public static void AddSubjectListBoxEditMode(this AddBookForm addBookForm, List<string> subjects)
		{
			
		}
	}
}