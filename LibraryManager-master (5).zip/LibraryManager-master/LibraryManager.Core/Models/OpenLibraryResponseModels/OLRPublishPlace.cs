namespace LibraryManager.Core.Models.OpenLibraryResponseModels;
[Obsolete("Response from OpenLibrary API.")]
public class OLRPublishPlace
{
	public string? Name { get; set; }
}