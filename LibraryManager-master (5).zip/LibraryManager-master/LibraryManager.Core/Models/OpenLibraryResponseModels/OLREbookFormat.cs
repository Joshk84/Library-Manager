namespace LibraryManager.Core.Models.OpenLibraryResponseModels;

[Obsolete("Response from OpenLibrary API.")]
public class OLREbookFormat
{
	public string? Url { get; set; }
}