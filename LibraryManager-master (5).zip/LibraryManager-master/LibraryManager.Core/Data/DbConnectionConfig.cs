﻿namespace LibraryManager.Core.Data;

public class DbConnectionConfig
{
	public string ConnectionString { get; set; }
	public string ProviderName { get; set; }
	
}